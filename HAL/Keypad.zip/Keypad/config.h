/*
 * config.h
 *
 * Created: 10/22/2023 9:36:32 AM
 *  Author: zaher
 */ 


#ifndef CONFIG_H_
#define CONFIG_H_
#include "../../LIB/type.h"
#include "../../MCAL/DIO/interface.h"


// keyPad port dif
#define Keypad_ROW_PORT PORT_C
#define Keypad_COL_PORT PORT_D
u8 Keypad_PORT_ROW_COL[2]={PORT_C,PORT_D};

// keyPad pin dif
//row
#define Keypad_ROW_1_PIN pin5
#define Keypad_ROW_2_PIN pin4
#define Keypad_ROW_3_PIN pin3
#define Keypad_ROW_4_PIN pin2
u8 keyPad_ROW_PIN[4]={pin5,pin4,pin3,pin2};
//col
#define Keypad_COL_1_PIN pin7
#define Keypad_COL_2_PIN pin6
#define Keypad_COL_3_PIN pin5
#define Keypad_COL_4_PIN pin3
u8 keyPad_COL_PIN[4]={pin7,pin6,pin5,pin3};
	
// ARR_DATA

//#define ARR_DATA {{'7','8','9','a'},{'4','5','6','b'},{'1','2','3','c'},{'g','f','e','f'}}
	#define ARR_DATA {{7,8,9,0},{4,5,6,0},{1,2,3,0},{0,0,0,0}}





#endif /* CONFIG_H_ */